<?php
if($_SERVER["REQUEST_METHOD"]=="POST"){
  $name=$_POST["name"];
  $email=$_POST["email"];
  $message=$_POST["message"];
  $to="sakuralanguagea@gmail.com"; // CHANGE THIS
  $subject="New Contact - VPS Japan Employe Agency";
  $body="Name: $name\nEmail: $email\nMessage:\n$message";
  $headers="From: $email";
  mail($to,$subject,$body,$headers);
}
?>